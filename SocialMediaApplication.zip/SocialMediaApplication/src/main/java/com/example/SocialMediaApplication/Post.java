package com.example.SocialMediaApplication;

public interface Post {
	public String getMessage();
	public void setMessage(String message);
}
